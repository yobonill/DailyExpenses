import { useMemo, useState, type FormEvent } from "react";
import { EXPENSE_CATEGORIES, isPredefinedExpenseCategory } from "../../config/financeCategories";
import { formatShortDate, toLocalDateKey } from "../../lib/date";
import { addMonthsToDateKey } from "../../lib/financeDates";
import { deriveDatedStatus, getFutureOccurrenceFunding, getFundAllocated, getFundBalance, isNonMonthlyWarningActive, statusLabel } from "../../lib/financialCalculations";
import { formatCurrency, minorToInput, parseMoneyToCents } from "../../lib/money";
import type { CreditCard, Currency, FinancialData, NonMonthlyExpense, NonMonthlyOccurrence } from "../../models/finance";
import type { NonMonthlyInput } from "../../hooks/useFinanceActions";
import { CheckboxField, CurrencyField, EmptyPanel, Modal, MoneyField, PageHeading, PayModal, PostponeModal, StatusChip, type PayModalValue } from "./Shared";

function FutureExpenseForm({ data, plan, defaultWarning, onSave, onClose }: { data: FinancialData; plan?: NonMonthlyExpense; defaultWarning: number; onSave: (input: NonMonthlyInput, id?: string) => Promise<void>; onClose: () => void }) {
  const [name, setName] = useState(plan?.name || "");
  const [category, setCategory] = useState(plan?.category || "");
  const [amount, setAmount] = useState(minorToInput(plan?.estimatedAmountMinor));
  const [currency, setCurrency] = useState<Currency>(plan?.currency || "DOP");
  const [loanId, setLoanId] = useState(plan?.loanId || "");
  const [nextDueDate, setNextDueDate] = useState(plan?.nextDueDate || addMonthsToDateKey(toLocalDateKey(), 3));
  const [recurrenceKind, setRecurrenceKind] = useState<"once" | "months" | "years">(plan?.recurrenceKind || "once");
  const [interval, setInterval] = useState(String(plan?.recurrenceInterval || 1));
  const [warning, setWarning] = useState(String(plan?.warningMonths ?? defaultWarning));
  const [canPayWithCard, setCanPayWithCard] = useState(plan?.canPayWithCard ?? true);
  const [active, setActive] = useState(plan?.active ?? true);
  const [notes, setNotes] = useState(plan?.notes || "");
  const [error, setError] = useState(""); const [saving, setSaving] = useState(false);
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    const estimatedAmountMinor = parseMoneyToCents(amount);
    const recurrenceInterval = Math.max(1, Number(interval) || 1);
    const warningMonths = Math.max(0, Number(warning) || 0);
    if (!name.trim() || !estimatedAmountMinor || !nextDueDate) return setError("Completa nombre, monto y próxima fecha.");
    setSaving(true); setError("");
    try {
      await onSave({ name, category, estimatedAmountMinor, currency, nextDueDate, recurrenceKind, recurrenceInterval, warningMonths, canPayWithCard, active, notes, loanId: category === "Deudas y préstamos" ? loanId || undefined : undefined }, plan?.id);
      onClose();
    } catch (reason) { setError(reason instanceof Error ? reason.message : "No se pudo guardar."); }
    finally { setSaving(false); }
  };
  return <Modal title={plan ? "Editar gasto no mensual" : "Nuevo gasto no mensual"} onClose={onClose}><form className="form-grid" onSubmit={submit}>
    <label className="field"><span>Nombre</span><input value={name} onChange={(event) => setName(event.target.value)} required /></label>
    <label className="field"><span>Categoría (opcional)</span><select value={category} onChange={(event) => { const next = event.target.value; setCategory(next); if (next !== "Deudas y préstamos") setLoanId(""); }}><option value="">Sin categoría</option>{category && !isPredefinedExpenseCategory(category) && <option value={category}>{category} (anterior)</option>}{EXPENSE_CATEGORIES.map((item) => <option value={item} key={item}>{item}</option>)}</select></label>
    {category === "Deudas y préstamos" && <label className="field"><span>Préstamo relacionado (opcional)</span><select value={loanId} onChange={(event) => setLoanId(event.target.value)}><option value="">No vincular</option>{Object.values(data.loans).filter((loan) => !loan.archivedAt && loan.currency === currency).map((loan) => <option key={loan.id} value={loan.id}>{loan.name}</option>)}</select></label>}
    <div className="form-columns"><MoneyField label="Costo estimado" value={amount} onChange={setAmount} currency={currency} /><CurrencyField value={currency} onChange={setCurrency} /></div>
    <label className="field"><span>Próximo vencimiento</span><input type="date" value={nextDueDate} onChange={(event) => setNextDueDate(event.target.value)} /></label>
    <div className="form-columns"><label className="field"><span>Repetición</span><select value={recurrenceKind} onChange={(event) => setRecurrenceKind(event.target.value as typeof recurrenceKind)}><option value="once">Una sola vez</option><option value="months">Cada X meses</option><option value="years">Cada X años</option></select></label>{recurrenceKind !== "once" && <label className="field"><span>Intervalo</span><input type="number" min="1" value={interval} onChange={(event) => setInterval(event.target.value)} /></label>}</div>
    <label className="field"><span>Avisar con meses de anticipación</span><input type="number" min="0" max="60" value={warning} onChange={(event) => setWarning(event.target.value)} /></label>
    <CheckboxField checked={canPayWithCard} onChange={setCanPayWithCard} label="Se puede pagar con tarjeta" /><CheckboxField checked={active} onChange={setActive} label="Plan activo" />
    <label className="field"><span>Notas</span><textarea value={notes} onChange={(event) => setNotes(event.target.value)} /></label>
    {error && <p className="form-error">{error}</p>}<div className="modal-actions"><button type="button" className="button button-secondary" onClick={onClose}>Cancelar</button><button className="button button-primary" disabled={saving}>{saving ? "Guardando…" : "Guardar"}</button></div>
  </form></Modal>;
}

function AllocationModal({ data, occurrence, onAllocate, onClose }: { data: FinancialData; occurrence: NonMonthlyOccurrence; onAllocate: (fundId: string, amount: number) => Promise<void>; onClose: () => void }) {
  const funds = Object.values(data.savingsFunds).filter((fund) => fund.active && fund.currency === occurrence.currency && !fund.archivedAt);
  const [fundId, setFundId] = useState(funds[0]?.id || ""); const [amount, setAmount] = useState(""); const [error, setError] = useState(""); const [saving, setSaving] = useState(false);
  const submit = async (event: FormEvent) => { event.preventDefault(); const value = parseMoneyToCents(amount); if (!fundId || !value) return setError("Selecciona un fondo y un monto."); setSaving(true); setError(""); try { await onAllocate(fundId, value); onClose(); } catch (reason) { setError(reason instanceof Error ? reason.message : "No se pudo reservar."); } finally { setSaving(false); } };
  return <Modal title={`Reservar para ${occurrence.name}`} onClose={onClose}><form className="form-grid" onSubmit={submit}>{!funds.length ? <p className="form-error">No hay fondos activos en {occurrence.currency}.</p> : <><label className="field"><span>Fondo</span><select value={fundId} onChange={(event) => setFundId(event.target.value)}>{funds.map((fund) => <option key={fund.id} value={fund.id}>{fund.name} · Disponible {formatCurrency(getFundBalance(data, fund.id) - getFundAllocated(data, fund.id), fund.currency)}</option>)}</select></label><MoneyField label="Monto a reservar" value={amount} onChange={setAmount} currency={occurrence.currency} /></>}{error && <p className="form-error">{error}</p>}<div className="modal-actions"><button type="button" className="button button-secondary" onClick={onClose}>Cancelar</button><button className="button button-primary" disabled={saving || !funds.length}>Reservar</button></div></form></Modal>;
}

export function FutureExpensesView({ data, onSave, onPay, onPostpone, onReopen, onAllocate }: {
  data: FinancialData;
  onSave: (input: NonMonthlyInput, id?: string) => Promise<void>;
  onPay: (value: PayModalValue & { sourceType: "nonMonthly"; sourceId: string; currency: Currency }) => Promise<void>;
  onPostpone: (sourceType: "nonMonthly", sourceId: string, newDueDate: string) => Promise<void>;
  onReopen: (id: string) => Promise<void>;
  onAllocate: (fundId: string, occurrenceId: string, amount: number) => Promise<void>;
}) {
  const [form, setForm] = useState<NonMonthlyExpense | "new" | null>(null); const [paying, setPaying] = useState<NonMonthlyOccurrence | null>(null); const [postponing, setPostponing] = useState<NonMonthlyOccurrence | null>(null); const [allocating, setAllocating] = useState<NonMonthlyOccurrence | null>(null); const [showCompleted, setShowCompleted] = useState(false);
  const [initialPayMethod, setInitialPayMethod] = useState<"cash" | "bankTransfer" | "creditCard">("bankTransfer");
  const horizon = addMonthsToDateKey(toLocalDateKey(), 12); const occurrences = useMemo(() => Object.values(data.nonMonthlyOccurrences).filter((item) => (showCompleted || item.status === "upcoming") && (item.dueDate <= horizon || item.status !== "upcoming")).sort((a, b) => a.dueDate.localeCompare(b.dueDate)), [data.nonMonthlyOccurrences, horizon, showCompleted]);
  const plans = useMemo(() => Object.values(data.nonMonthlyExpenses).filter((plan) => !plan.archivedAt).sort((a, b) => a.nextDueDate.localeCompare(b.nextDueDate)), [data.nonMonthlyExpenses]); const cards = Object.values(data.creditCards).filter((card) => card.active && !card.archivedAt);
  const required = (currency: Currency) => occurrences.filter((item) => item.currency === currency && item.status === "upcoming").reduce((total, item) => total + item.expectedAmountMinor, 0); const reserved = (currency: Currency) => occurrences.filter((item) => item.currency === currency && item.status === "upcoming").reduce((total, item) => total + getFutureOccurrenceFunding(data, item).reservedMinor, 0);
  return <section className="finance-page"><PageHeading eyebrow="Plan futuro" title="Gastos no mensuales" action={<button className="button button-primary heading-action" type="button" onClick={() => setForm("new")}>＋ Agregar</button>} /><p className="period-caption">Próximos 12 meses visibles, aunque todavía no estén dentro del período de alerta.</p><div className="projection-grid"><article className="projection-card"><span>Plan DOP</span><strong>{formatCurrency(required("DOP"), "DOP")}</strong><small>Reservado {formatCurrency(reserved("DOP"), "DOP")} · Falta {formatCurrency(Math.max(0, required("DOP") - reserved("DOP")), "DOP")}</small></article><article className="projection-card"><span>Plan USD</span><strong>{formatCurrency(required("USD"), "USD")}</strong><small>Reservado {formatCurrency(reserved("USD"), "USD")} · Falta {formatCurrency(Math.max(0, required("USD") - reserved("USD")), "USD")}</small></article></div><div className="list-toolbar"><CheckboxField checked={showCompleted} onChange={setShowCompleted} label="Mostrar historial completado" /></div>
    {!occurrences.length ? <EmptyPanel title="Sin gastos futuros" text="Registra seguros, renovaciones, mantenimiento y otros pagos conocidos." /> : <div className="finance-list">{occurrences.map((item) => { const plan = data.nonMonthlyExpenses[item.planId]; const funding = getFutureOccurrenceFunding(data, item); const today = toLocalDateKey(); const immediateStatus = deriveDatedStatus(item, today, 0); const warningMonths = plan?.warningMonths ?? data.settings.nonMonthlyWarningMonths; const status = immediateStatus === "upcoming" && isNonMonthlyWarningActive(item, today, warningMonths) ? "dueSoon" : immediateStatus; const fundingLabel = funding.status === "unfunded" ? "Sin fondos" : funding.status === "partial" ? "Parcial" : funding.status === "funded" ? "Cubierto" : "Sobreasignado"; return <article className="finance-row-card" key={item.id}><div className="finance-row-main"><div><div className="row-title-line"><h3>{item.name}</h3><StatusChip status={item.status === "paid" ? "paid" : status} label={item.status === "paid" ? "Pagado" : status === "dueSoon" ? "Planificar" : statusLabel(status)} /><StatusChip status={funding.status} label={fundingLabel} />{item.postponedAt && <StatusChip status="partial" label="Postergado" />}</div><p>Vence {formatShortDate(item.dueDate)} · {plan?.recurrenceKind === "once" ? "Una vez" : plan?.recurrenceKind === "years" ? `Cada ${plan.recurrenceInterval} año(s)` : `Cada ${plan?.recurrenceInterval} mes(es)`}</p>{item.originalDueDate && <small className="postponed-note">Fecha original: {formatShortDate(item.originalDueDate)}</small>}<small>Reservado {formatCurrency(funding.reservedMinor, item.currency)} · Falta {formatCurrency(funding.missingMinor, item.currency)}</small></div><strong>{formatCurrency(item.expectedAmountMinor, item.currency)}</strong></div><div className="row-actions">{item.status === "upcoming" ? <><button className="button button-primary" type="button" onClick={() => { setInitialPayMethod("cash"); setPaying(item); }}>Pagar</button>{item.canPayWithCard && <button className="button button-secondary" type="button" onClick={() => { setInitialPayMethod("creditCard"); setPaying(item); }}>Pagar con tarjeta</button>}<button className="button button-secondary" type="button" onClick={() => setPostponing(item)}>Postergar</button><button className="button button-secondary" type="button" onClick={() => setAllocating(item)}>Reservar</button>{plan && <button className="button button-quiet" type="button" onClick={() => setForm(plan)}>Editar plan</button>}</> : <button className="button button-secondary" type="button" onClick={() => { if (window.confirm("¿Reabrir este gasto y revertir movimientos vinculados?")) void onReopen(item.id); }}>Corregir / reabrir</button>}</div></article>; })}</div>}
    <section className="management-section"><div className="section-title-row"><div><span className="eyebrow">Definiciones</span><h2>Planes configurados</h2></div></div><div className="template-list">{plans.map((plan) => <article key={plan.id}><div><strong>{plan.name}</strong><span>Próximo: {formatShortDate(plan.nextDueDate)} · {formatCurrency(plan.estimatedAmountMinor, plan.currency)}</span></div><StatusChip status={plan.active ? "paid" : "cancelled"} label={plan.active ? "Activo" : "Completado"} /><div className="inline-actions"><button type="button" onClick={() => setForm(plan)}>Editar</button></div></article>)}</div></section>
    {form && <FutureExpenseForm data={data} plan={form === "new" ? undefined : form} defaultWarning={data.settings.nonMonthlyWarningMonths} onSave={onSave} onClose={() => setForm(null)} />}{paying && <PayModal title={paying.name} expectedMinor={paying.expectedAmountMinor} currency={paying.currency} canPayWithCard={paying.canPayWithCard} cards={cards as CreditCard[]} data={data} loanId={paying.loanId} allowSavings initialMethod={initialPayMethod} onClose={() => setPaying(null)} onConfirm={(value) => onPay({ ...value, sourceType: "nonMonthly", sourceId: paying.id, currency: paying.currency })} />}{postponing && <PostponeModal title={postponing.name} currentDueDate={postponing.dueDate} onClose={() => setPostponing(null)} onConfirm={(newDueDate) => onPostpone("nonMonthly", postponing.id, newDueDate)} />}{allocating && <AllocationModal data={data} occurrence={allocating} onAllocate={(fundId, amount) => onAllocate(fundId, allocating.id, amount)} onClose={() => setAllocating(null)} />}
  </section>;
}
