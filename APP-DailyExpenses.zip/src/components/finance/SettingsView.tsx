import { useState, type ChangeEvent, type FormEvent } from "react";
import type { Expense, SyncState } from "../../models/expense";
import type { AppSettings, FinancialData } from "../../models/finance";
import { formatShortDate } from "../../lib/date";
import { createBackup, downloadBackup, restoreBackupAtomically, validateBackupText, type BackupPreview } from "../../services/backup";
import { Modal, PageHeading } from "./Shared";
import { useSyncLog } from "../../hooks/useSyncLog";

interface SyncDiagnosticChannel {
  state: SyncState;
  message: string;
  pendingCount: number;
}

const syncStateLabel = (state: SyncState): string => ({
  connecting: "Conectando",
  saving: "Sincronizando",
  synced: "Sincronizado",
  offline: "Sin conexión",
  error: "Error",
})[state];

const formatLogTimestamp = (timestamp: string): string => new Intl.DateTimeFormat("es-DO", {
  dateStyle: "short",
  timeStyle: "medium",
}).format(new Date(timestamp));

export function SettingsView({ data, expenses, syncPendingCount, syncDiagnostics, onRetrySync, onDiscardExpenseChanges, onUpdateSettings, onRecordBackup, canInstall, onInstall, onLogout }: {
  data: FinancialData;
  expenses: Expense[];
  syncPendingCount: number;
  syncDiagnostics: { expenses: SyncDiagnosticChannel; financial: SyncDiagnosticChannel };
  onRetrySync: () => Promise<void>;
  onDiscardExpenseChanges: () => number;
  onUpdateSettings: (settings: AppSettings) => Promise<void>;
  onRecordBackup: (timestamp: string) => Promise<void>;
  canInstall: boolean;
  onInstall: () => Promise<void>;
  onLogout: () => Promise<void>;
}) {
  const [monthlyDays, setMonthlyDays] = useState(String(data.settings.dueSoonDaysMonthly)); const [cardDays, setCardDays] = useState(String(data.settings.dueSoonDaysCards)); const [futureMonths, setFutureMonths] = useState(String(data.settings.nonMonthlyWarningMonths)); const [usdRate, setUsdRate] = useState(data.settings.estimatedUsdToDopRate > 0 ? String(data.settings.estimatedUsdToDopRate) : ""); const [transferFeeRate, setTransferFeeRate] = useState(String(data.settings.transferFeeRatePercent)); const [saved, setSaved] = useState(false); const [preview, setPreview] = useState<BackupPreview | null>(null); const [restoreText, setRestoreText] = useState(""); const [restoring, setRestoring] = useState(false); const [confirmation, setConfirmation] = useState("");
  const [retryingSync, setRetryingSync] = useState(false);
  const syncLog = useSyncLog();
  const retrySynchronization = async () => { setRetryingSync(true); try { await onRetrySync(); } finally { setRetryingSync(false); } };
  const discardExpenseChanges = () => {
    const count = syncDiagnostics.expenses.pendingCount;
    if (!count) return;
    const confirmed = window.confirm(`¿Descartar ${count} cambio${count === 1 ? "" : "s"} pendiente${count === 1 ? "" : "s"} de Gastos diarios?\n\nLos gastos que existen únicamente en este dispositivo desaparecerán. Presupuesto, tarjeta, ahorros y datos ya sincronizados no serán modificados.`);
    if (confirmed) onDiscardExpenseChanges();
  };
  const saveSettings = async (event: FormEvent) => { event.preventDefault(); await onUpdateSettings({ ...data.settings, dueSoonDaysMonthly: Math.max(0, Number(monthlyDays) || 0), dueSoonDaysCards: Math.max(0, Number(cardDays) || 0), nonMonthlyWarningMonths: Math.max(0, Number(futureMonths) || 0), estimatedUsdToDopRate: Math.max(0, Number(usdRate) || 0), transferFeeRatePercent: Math.max(0, Number(transferFeeRate) || 0) }); setSaved(true); window.setTimeout(() => setSaved(false), 2500); };
  const exportBackup = async () => { const backup = createBackup(data, expenses); downloadBackup(backup); await onRecordBackup(backup.exportedAt); };
  const selectBackup = async (event: ChangeEvent<HTMLInputElement>) => { const file = event.target.files?.[0]; if (!file) return; const text = await file.text(); setRestoreText(text); setPreview(validateBackupText(text)); setConfirmation(""); event.target.value = ""; };
  const restore = async () => { if (!preview?.backup || confirmation !== "RESTAURAR") return; setRestoring(true); try { downloadBackup(createBackup(data, expenses), "respaldo-seguridad-antes-de-restaurar"); await restoreBackupAtomically(preview.backup); window.location.reload(); } catch { setRestoring(false); setPreview({ ...preview, errors: [...preview.errors, "No se pudo restaurar. Los datos actuales no fueron reemplazados."], valid: false }); } };
  return <section className="finance-page"><PageHeading eyebrow="Sistema" title="Configuración" /><section className="settings-card"><h2>Avisos y proyecciones del Dashboard</h2><form className="form-grid" onSubmit={saveSettings}><div className="form-columns"><label className="field"><span>Gastos mensuales · días antes</span><input type="number" min="0" max="90" value={monthlyDays} onChange={(event) => setMonthlyDays(event.target.value)} /></label><label className="field"><span>Tarjetas · días antes</span><input type="number" min="0" max="90" value={cardDays} onChange={(event) => setCardDays(event.target.value)} /></label></div><label className="field"><span>Gastos no mensuales · meses antes</span><input type="number" min="0" max="60" value={futureMonths} onChange={(event) => setFutureMonths(event.target.value)} /></label><label className="field"><span>Tasa estimada DOP por USD (opcional)</span><input type="number" min="0" step="0.01" inputMode="decimal" value={usdRate} onChange={(event) => setUsdRate(event.target.value)} placeholder="Ej. 63.25" /><small className="field-help">Solo convierte la proyección USD a un equivalente aproximado en pesos. No modifica la deuda ni los pagos reales de la tarjeta.</small></label><label className="field"><span>Comisión sugerida por transferencia (%)</span><input type="number" min="0" step="0.01" inputMode="decimal" value={transferFeeRate} onChange={(event) => setTransferFeeRate(event.target.value)} /><small className="field-help">Valor inicial: 0.15%. Cada pago permite activarla, editarla o dejarla en cero.</small></label><div className="modal-actions"><span className="save-confirmation">{saved ? "Guardado" : ""}</span><button className="button button-primary">Guardar configuración</button></div></form></section>
    <section className="settings-card"><h2>Respaldo compartido</h2><p>El respaldo incluye gastos diarios, presupuesto, ingresos, bancos, cuentas, efectivo, tarjetas, préstamos, gastos futuros, metas de compra, ahorros y configuración.</p><div className="settings-actions"><button className="button button-primary" type="button" onClick={() => void exportBackup()}>Descargar respaldo JSON</button><label className="button button-secondary file-button">Seleccionar respaldo<input type="file" accept="application/json,.json" onChange={(event) => void selectBackup(event)} /></label></div>{data.lastBackupAt && <small>Último respaldo registrado: {formatShortDate(data.lastBackupAt.slice(0, 10))}</small>}<p className="privacy-note">Restaurar reemplaza el conjunto compartido para Yorki y Yisel. Antes de hacerlo se descarga automáticamente un respaldo de seguridad.</p></section>
    <section className="settings-card"><div className="settings-section-heading"><div><h2>Diagnóstico de sincronización</h2><p>El registro técnico se guarda únicamente en este dispositivo y nunca incluye montos, nombres de gastos, contraseñas ni datos de la tarjeta.</p></div><button className="button button-secondary" type="button" disabled={retryingSync} onClick={() => void retrySynchronization()}>{retryingSync ? "Reintentando…" : "Reintentar sincronización"}</button></div><div className="sync-channel-grid"><article><div><strong>Gastos diarios</strong><span className={`status-chip ${syncDiagnostics.expenses.state === "error" || syncDiagnostics.expenses.state === "offline" ? "status-danger" : syncDiagnostics.expenses.state === "synced" ? "status-success" : "status-warning"}`}>{syncStateLabel(syncDiagnostics.expenses.state)}</span></div><p>{syncDiagnostics.expenses.message}</p><small>Pendientes: {syncDiagnostics.expenses.pendingCount}</small></article><article><div><strong>Presupuesto y finanzas</strong><span className={`status-chip ${syncDiagnostics.financial.state === "error" || syncDiagnostics.financial.state === "offline" ? "status-danger" : syncDiagnostics.financial.state === "synced" ? "status-success" : "status-warning"}`}>{syncStateLabel(syncDiagnostics.financial.state)}</span></div><p>{syncDiagnostics.financial.message}</p><small>Pendientes: {syncDiagnostics.financial.pendingCount}</small></article></div>{syncDiagnostics.expenses.pendingCount > 0 && <div className="settings-actions"><button className="button button-quiet danger-text" type="button" disabled={retryingSync || syncDiagnostics.expenses.state === "saving"} onClick={discardExpenseChanges}>Descartar pendientes de Gastos diarios</button><small>Elimina solamente la cola local de Gastos diarios y vuelve a mostrar los datos guardados en Firebase.</small></div>}<div className="sync-log-heading"><h3>Registro local</h3>{syncLog.entries.length > 0 && <button className="text-button" type="button" onClick={syncLog.clear}>Limpiar registro</button>}</div>{syncLog.entries.length ? <div className="sync-log-list">{syncLog.entries.map((entry) => <article className={`sync-log-entry sync-log-${entry.level}`} key={entry.id}><div><strong>{entry.source}</strong><time dateTime={entry.timestamp}>{formatLogTimestamp(entry.timestamp)}</time></div><p>{entry.message}</p></article>)}</div> : <p className="muted-panel">Todavía no hay eventos de sincronización registrados.</p>}</section>
    <section className="settings-card"><h2>Aplicación</h2><dl className="settings-details"><div><dt>Versión</dt><dd>1.9.0</dd></div><div><dt>Esquema de datos</dt><dd>1</dd></div>{data.settings.trackingStartDate && <div><dt>Seguimiento exacto desde</dt><dd>{formatShortDate(data.settings.trackingStartDate)}</dd></div>}<div><dt>Cambios por sincronizar</dt><dd>{syncPendingCount}</dd></div><div><dt>Desarrollo</dt><dd>Puerto 42871</dd></div><div><dt>Vista previa</dt><dd>Puerto 42872</dd></div></dl><div className="settings-actions">{canInstall && <button className="button button-secondary" type="button" onClick={() => void onInstall()}>Instalar aplicación</button>}<button className="button button-quiet danger-text" type="button" onClick={() => { if (window.confirm("¿Cerrar la sesión guardada en este dispositivo?")) void onLogout(); }}>Cerrar sesión</button></div></section>
    {preview && <Modal title={preview.valid ? "Revisar restauración" : "Respaldo no válido"} onClose={() => setPreview(null)}><div className="restore-preview">{preview.errors.map((error) => <p className="validation-error" key={error}>{error}</p>)}{preview.valid && <><p>Fecha del respaldo: <strong>{preview.exportedAt?.slice(0, 10)}</strong></p><dl>{Object.entries(preview.counts).map(([label, count]) => <div key={label}><dt>{label}</dt><dd>{count}</dd></div>)}</dl><p className="form-error">Esta acción reemplazará los datos compartidos actuales en ambos dispositivos.</p><label className="field"><span>Escribe RESTAURAR para confirmar</span><input value={confirmation} onChange={(event) => setConfirmation(event.target.value)} autoComplete="off" /></label></>}</div><div className="modal-actions"><button className="button button-secondary" type="button" onClick={() => setPreview(null)}>Cancelar</button>{preview.valid && <button className="button button-primary" type="button" disabled={confirmation !== "RESTAURAR" || restoring || !restoreText} onClick={() => void restore()}>{restoring ? "Restaurando…" : "Restaurar datos compartidos"}</button>}</div></Modal>}
  </section>;
}
