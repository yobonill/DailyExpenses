const CACHE_PREFIX = "daily-expenses-budget-shell-";
const CACHE_NAME = `${CACHE_PREFIX}v8`;
const APP_ROOT = self.registration.scope;
const SHELL_URLS = [
  APP_ROOT,
  new URL("index.html", APP_ROOT).toString(),
  new URL("manifest.webmanifest", APP_ROOT).toString(),
  new URL("icons/icon-192.png", APP_ROOT).toString(),
  new URL("icons/icon-512.png", APP_ROOT).toString(),
  new URL("templates/Presupuesto-2026.xlsx", APP_ROOT).toString(),
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(SHELL_URLS))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((key) => key.startsWith(CACHE_PREFIX) && key !== CACHE_NAME).map((key) => caches.delete(key))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
          return response;
        })
        .catch(async () =>
          (await caches.match(request)) ||
          (await caches.match(new URL("index.html", APP_ROOT).toString())) ||
          (await caches.match(APP_ROOT)),
        ),
    );
    return;
  }

  event.respondWith(
    caches.match(request).then((cached) => {
      const network = fetch(request)
        .then((response) => {
          if (response.ok) {
            const copy = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
          }
          return response;
        })
        .catch(() => cached);
      return cached || network;
    }),
  );
});
